package kiosk;

public class SHMenu2 {
    // 버거 가격   
   public static int [] burgerPrice = {4600, 5200, 5200, 5500, 6500, 7900, 8900};
   public static String[] burger = {"불고기버거", "치즈버거", "새우버거", 
         "치킨버거", "베이컨치즈버거", "더블비프치즈버거", "스페셜버거"};
   public static int [] setPrice = {8100, 8700, 8700, 9000, 10000, 11400, 12400}; // 세트 금액
   public static String[] burgerset = {"불고기버거세트", "치즈버거세트", "새우버거세트", 
   "치킨버거세트", "베이컨치즈버거세트", "더블비프치즈버거세트", "스페셜버거세트"};
   // 토핑 가격  
   public static int[] addToppingPrice = {600, 800, 1600, 2500, 0};
   public static String[] addTopping = {"토마토 추가", "치즈 추가", "베이컨 추가", "비프패티 추가", "추가토핑 X"};
    
   // 사이드 디쉬 가격
   public static int[] sideMenuPrice = {2100,2600,2600,2900,2800,1900,0};
   public static String[] sideMenu = {"프렌치프라이", "양념감자", "치즈스틱", "치킨너겟", "오징어링", "콘샐러드","사이드 X"};
   
   // 음료 가격 
   public static int[] drinkPrice = {2000, 2000, 2300, 2500, 2700, 1500, 2500, 1000,0};
   public static String[] drink = {"콜라(R)", "사이다(R)", "아이스티(R)", "아메리카노(R)", "레몬에이드(R)", "우유(R)", "핫초코(R)", "생수(R)", "음료 X"};
   
   public static int[] drinkSizeUpPrice = {2700, 2700, 3000, 3200, 3400, 2200, 3200, 1700,0};
   public static String[] drinkSizeUp = {"콜라(L)", "사이다(L)", "아이스티(L)", "아메리카노(L)", "레몬에이드(L)", "우유(L)", "핫초코(L)", "생수(L)", "음료 X"};
}